/**
 * Internal dependencies
 */
import './media-blocks';
