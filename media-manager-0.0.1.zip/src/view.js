/**
 * Internal dependencies
 */
import './block-library/view';
import './extending/view';
