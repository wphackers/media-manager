/**
 * Internal dependencies
 */
import './play-pause-button/view';
