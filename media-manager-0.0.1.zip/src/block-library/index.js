/**
 * Internal dependencies
 */
import './media-center';
import './media-player';
import './play-button';
import './pause-button';
import './play-pause-button';
import './time-position';
